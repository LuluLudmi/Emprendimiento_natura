package emprendimiento.natura.gilma.aguada.repositories.interfaces;

public interface I_DetallePedidoRepository {

}
