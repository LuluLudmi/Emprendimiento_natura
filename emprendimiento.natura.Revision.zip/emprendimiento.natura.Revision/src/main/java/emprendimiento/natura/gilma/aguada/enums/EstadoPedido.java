
package emprendimiento.natura.gilma.aguada.enums;

public enum EstadoPedido {
    PENDIENTE("Pendiente"),
    CONFIRMADO("Confirmado"),
    ENVIADO("Enviado"),
    ENTREGADO("Entregado"),
    CANCELADO("Cancelado");

    private final String dbValue;

    EstadoPedido(String dbValue) {
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return dbValue; // Qué es dbValue?
                        // dbValue es la representación en formato de texto (String) de cada constante de la enumeración EstadoPedido 
                        // que se utiliza para interactuar con la base de datos.
    }

    public static EstadoPedido fromDbValue(String value) {
        if (value == null) { // Si el valor de la base de datos es nulo, lanza una excepción porque
                             // un estado de pedido no debería ser nulo en tu lógica
            throw new IllegalArgumentException("Estado de pedido nulo.");
        }
        String trimmedValue = value.trim();

        System.out.println("DEBUG: Valor de DB recibido: '" + value + "' (length: " + value.length() + ")"); // Estas líneas son para depuración (debug). 
        System.out.println("DEBUG: Valor TRIMEADO: '" + trimmedValue + "' (length: " + trimmedValue.length() + ")"); // elimina cualquier espacio en blanco
                                                                                                                     // al principio o al final de la cadena

        for (EstadoPedido estado : EstadoPedido.values()) {
            if (estado.dbValue.equalsIgnoreCase(trimmedValue)) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Estado de pedido desconocido: '" + value + "'");
    }
}