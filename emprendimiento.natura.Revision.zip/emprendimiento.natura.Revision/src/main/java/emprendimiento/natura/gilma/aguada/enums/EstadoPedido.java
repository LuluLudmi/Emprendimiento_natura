package emprendimiento.natura.gilma.aguada.enums;

public enum EstadoPedido {
    PENDIENTE("Pendiente"),
    CONFIRMADO("Confirmado"),
    ENVIADO("Enviado"),
    ENTREGADO("Entregado"),
    CANCELADO("Cancelado");

    private final String dbValue;

    EstadoPedido(String dbValue) {
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return dbValue;
    }

    // Opcional: un método estático para obtener el enum a partir del valor de la DB
    public static EstadoPedido fromDbValue(String value) {
        for (EstadoPedido estado : EstadoPedido.values()) {
            if (estado.dbValue.equalsIgnoreCase(value)) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Estado de pedido desconocido: " + value);
    }
}
